chrome.runtime.onInstalled.addListener(function() {
    chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
      chrome.declarativeContent.onPageChanged.addRules([{
        conditions: [new chrome.declarativeContent.PageStateMatcher({
          pageUrl: {hostEquals: 'sebastian9.github.io'},
        })
        ],
            actions: [new chrome.declarativeContent.ShowPageAction()]
      }]);
    });
  });

chrome.commands.onCommand.addListener(function(command) {
  chrome.tabs.query({'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT}, function(tabs){
        if ( tabs[0].url.includes('sebastian9.github.io') ) {
          alert('Command:' + command);
          chrome.tabs.executeScript({
            file: 'test.js'
          });
        }
     });
});
