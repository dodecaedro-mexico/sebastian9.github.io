alert( document.getElementById('P').value );
